import numpy as np
import sounddevice as sd
import threading
import time

# Configuration
SAMPLE_RATE = 48000            # standard sample rate (change if you need 56888)
BLOCKSIZE = 4096               # block size for callback
THRESHOLD = 20.0               # tune this for your environment
DETECTION_BAND = (510, 520)    # Hz
SMOOTHING_ALPHA = 0.2          # EMA smoothing for band power
MIN_TRIGGER_INTERVAL = 1.0     # seconds between triggers to avoid repeats

state = {
    "ema_power": 0.0,
    "last_trigger_time": 0.0,
    "detected": False,
}

def trigger_action(band_power):
    # Placeholder: replace with GPIO call, mute command, or other action
    print(f"[TRIGGER] 510–520 Hz detected! band_power={band_power:.2f}")

def callback(indata, frames, time_info, status):
    if status:
        print("Stream status:", status)

    audio_data = indata[:, 0].astype(np.float32)
    # Window to reduce spectral leakage
    window = np.hanning(len(audio_data))
    fft_data = np.abs(np.fft.rfft(audio_data * window))
    freqs = np.fft.rfftfreq(len(audio_data), 1.0 / SAMPLE_RATE)

    band_indices = np.where((freqs >= DETECTION_BAND[0]) & (freqs <= DETECTION_BAND[1]))[0]
    if band_indices.size == 0:
        return

    # Compute average spectral magnitude in the band
    band_power = np.mean(fft_data[band_indices])

    # Smooth the measurement with exponential moving average to reduce spikes
    ema = state["ema_power"]
    ema = (SMOOTHING_ALPHA * band_power) + ((1.0 - SMOOTHING_ALPHA) * ema)
    state["ema_power"] = ema

    now = time.time()
    if ema > THRESHOLD:
        if not state["detected"] or (now - state["last_trigger_time"]) >= MIN_TRIGGER_INTERVAL:
            state["detected"] = True
            state["last_trigger_time"] = now
            # perform trigger in separate thread to keep callback fast
            threading.Thread(target=trigger_action, args=(ema,), daemon=True).start()
        print(f"[!] 510–520 Hz detected! EMA band power = {ema:.2f}")
    else:
        if state["detected"]:
            # detection cleared
            state["detected"] = False
            print(f"[i] Detection cleared. EMA band power = {ema:.2f}")
        else:
            # occasional status print to avoid flooding
            print(f"Band power (EMA) = {ema:.2f} (below threshold)")

if __name__ == "__main__":
    try:
        with sd.InputStream(callback=callback, channels=1, samplerate=SAMPLE_RATE, blocksize=BLOCKSIZE):
            print("Listening for 510–520 Hz... Press Ctrl+C to stop.")
            while True:
                time.sleep(0.2)
    except KeyboardInterrupt:
        print("Stopped by user.")
    except Exception as e:
        print("Stream error:", e)